var Group = function (pGon, tId) //Must receive ID, map, lattitude, and longitude
{
	this.Id = tId;
	this.pGon = pGon;
	return this;
};

function removeGroup(expObj, tId) {
	//var str = "removeGroup(";
	//str += expObj;
	//str += ", ";
	//str += tId;
	//str += ")";
	//log(str);

	var iid = tId + 0;
	//log(iid);
	groupArray[iid].pGon.setMap(null);
	groupArray[iid] = null;
};

function makeGroup(expObj, numId, idString, tId, hullColor) {
	//log("makeGroup");
	//log(numId);
	//log(idString);
	////log(tId);
	////log(hullColor);
	var hullPoints = new Array();
	var groupingMarkers = new Array();
	var idArray = idString.split(" "); 
	for (var j = 0; j < numId; j++) {
		groupingMarkers[j] = markerArray[parseInt(idArray[j])];
	};
	var numP = numId;
	convexHull(groupingMarkers, numP, hullPoints);
	var pgonPoints = new Array();
	var QtPts = new Array();
	for (var i = 0; i < hullPoints.length; i++) {
		//log(hullPoints[i].lng());
		pgonPoints.push(new google.maps.LatLng(hullPoints[i].lat(), hullPoints[i].lng()));
		QtPts.push(hullPoints[i].lat());
		QtPts.push(hullPoints[i].lng());
	};
	var pgon = new google.maps.Polygon({
		paths: pgonPoints,
		strokeColor: hullColor,
		strokeOpacity: 0.8,
		strokeWeight: 2,
		fillColor: hullColor,
		fillOpacity: 0.35,
		zIndex: 1
	});
	////log(QtPts.length);
	pgon.setMap(map);
	var tGroup = new Group(pgon, tId);
	groupArray[tId] = tGroup;
	expObj.receiveHullPoints(QtPts, tId);
};


function convexHull(groupedMarkers, numPoints, hullPoints) {
	////log("convexHull");
	// Use Google Maps� point class or any point class with x() and y() methods defined
	var points = [];
	//var hullPoints = [];
	var hullPoints_size;
	var pad = 0.0000255435;
	// Add a couple sample points to the array
	for (var i = 0; i < numPoints; i++) {
		points.push(new google.maps.LatLng(groupedMarkers[i].gMarker.getPosition().lat() + pad, groupedMarkers[i].gMarker.getPosition().lng() + pad));
		points.push(new google.maps.LatLng(groupedMarkers[i].gMarker.getPosition().lat() + pad, groupedMarkers[i].gMarker.getPosition().lng() - pad));
		points.push(new google.maps.LatLng(groupedMarkers[i].gMarker.getPosition().lat() - pad, groupedMarkers[i].gMarker.getPosition().lng() + pad));
		points.push(new google.maps.LatLng(groupedMarkers[i].gMarker.getPosition().lat() - pad, groupedMarkers[i].gMarker.getPosition().lng() - pad));
		//log(groupedMarkers[i].gMarker.getPosition().lat());
	}
	// Sort the points by X, then by Y (required by the algorithm)
	points.sort(sortPointY);
	points.sort(sortPointX);
	// Calculate the convex hull
	// Takes: an (1) array of points with x() and y() methods defined
	//          (2) Size of the points array
	//          (3) Empty array to store the hull points
	// Returns: The number of hull points, which may differ the the hull points array�s size
	hullPoints_size = chainHull_2D(points, points.length, hullPoints);
	//log(hullPoints_size);
	//log(hullPoints.length);
//	for (var j = 0; j < hullPoints.length; j++) {
//		log(hullPoints[j].lng());
//	}
	//log("that was log(hullPoints[j].lng;");
	//log(hullPoints.length);
};