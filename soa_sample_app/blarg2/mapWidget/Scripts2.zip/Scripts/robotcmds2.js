function scenario_2() {
    var time;

    var coefficient = 1;
    // ROBOT_SPEED /= 3;


    time = 0
    <JSEvent>
    <Time>time</Time>
    <Command>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.163917296691636, -86.78233623504638, affiliation.POLICE, robot_type.UAV);  window.police_1 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.163975763372136, -86.78239792585373, affiliation.POLICE, robot_type.UAV);  window.police_2 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.16400607941151, -86.782365739345555, affiliation.POLICE, robot_type.UAV);  window.police_3 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.16394328188834, -86.78228259086609, affiliation.POLICE, robot_type.UAV);   window.police_4 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.16477588633977, -86.78456246852875, affiliation.HAZMAT, robot_type.UAV);   window.hazmat_1 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.16473041272289, -86.78447127342224, affiliation.HAZMAT, robot_type.UAV);   window.hazmat_2 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.16482785615534, -86.78445786237716, affiliation.HAZMAT, robot_type.UGV);   window.hazmat_3 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.164784547978094, -86.78441762924194, affiliation.HAZMAT, robot_type.UGV);  window.hazmat_4 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.16487332971568, -86.78437739610672, affiliation.HAZMAT, robot_type.UGV);   window.hazmat_5 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.16480911980213, -86.78433688295547, affiliation.HAZMAT, robot_type.UGV);   window.hazmat_6 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.16539519106742, -86.78292632102966, affiliation.EMS, robot_type.UAV);      window.ems_1 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.1654861375035, -86.78298532962799, affiliation.EMS, robot_type.UAV);       window.ems_2 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.16544282968993, -86.78305774927139, affiliation.EMS, robot_type.UGV);      window.ems_3 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.165354048597365, -86.78301483392715, affiliation.EMS, robot_type.UGV);     window.ems_4 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.165393025674774, -86.78318649530411, affiliation.EMS, robot_type.UGV);     window.ems_5 = last_item;</Command>
</JSEvent>
<JSEvent>
    <Time>100</Time>
    <Command>add_robot(36.1653042445258, -86.78309798240661, affiliation.EMS, robot_type.UGV);       window.ems_6 = last_item;</Command>
</JSEvent>





<JSEvent>
    <Time>2000</Time>
    <Command>trigger(map, 'move_item', police_4, new LatLng(36.1646437962368, -86.78313553333282));</Command>
</JSEvent>
<JSEvent>
    <Time>2000</Time>
    <Command>trigger(map, 'move_item', police_1, new LatLng(36.1646437962368, -86.78313553333282));</Command>
</JSEvent>
<JSEvent>
    <Time>2000</Time>
    <Command>trigger(map, 'move_item', police_2, new LatLng(36.1646437962368, -86.78313553333282));</Command>
</JSEvent>
<JSEvent>
    <Time>2000</Time>
    <Command>trigger(map, 'move_item', police_3, new LatLng(36.1646437962368, -86.78313553333282));</Command>
</JSEvent>

    // tr
    <JSEvent>
    <Time>time</Time>
    <Command>
        trigger(police_1, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_1, new LatLng(36.165315071500586, -86.78171932697296)); }); });</Command>
</JSEvent>
        trigger(police_1, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_1, new LatLng(36.164856006457725, -86.78322941064835)); }); });</Command>
</JSEvent>
        trigger(police_1, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_1, new LatLng(36.165507791401275, -86.78190171718597)); }); });</Command>
</JSEvent>
        trigger(police_1, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_1, new LatLng(36.16499675781797, -86.78330987691879)); }); });</Command>
</JSEvent>
        trigger(police_1, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_1, new LatLng(36.165715668515794, -86.78204119205475)); }); });</Command>
</JSEvent>
        trigger(police_1, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_1, new LatLng(36.16515890308227, -86.78356468677521)); }); });</Command>
</JSEvent>
        trigger(police_1, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_1, new LatLng(36.16585399311749, -86.78214848041534)); }); });</Command>
</JSEvent>
        trigger(police_1, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_1, new LatLng(36.16533430021465, -86.7837256193161)); }); });</Command>
</JSEvent>
        trigger(police_1, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_1, new LatLng(36.16604238094385, -86.78223967552185)); }); });</Command>
</JSEvent>
        trigger(police_1, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_1, new LatLng(36.16557032783512, -86.78387850522995)); }); });</Command>
</JSEvent>
        trigger(police_1, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_1, new LatLng(36.16530831547907, -86.78316235542297)); }); }); 

        //br
        trigger(police_2, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_2, new LatLng(36.16458749546951, -86.78310066461563)); }); });</Command>
</JSEvent>
        trigger(police_2, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_2, new LatLng(36.16502707346249, -86.78156107664108)); }); });</Command>
</JSEvent>
        trigger(police_2, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_2, new LatLng(36.16434280320342, -86.78293436765671)); }); });</Command>
</JSEvent>
        trigger(police_2, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_2, new LatLng(36.16484734482729, -86.78143233060837)); }); });</Command>
</JSEvent>
        trigger(police_2, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_2, new LatLng(36.16416307299929, -86.78280293941498)); }); });</Command>
</JSEvent>
        trigger(police_2, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_2, new LatLng(36.16454418715945, -86.78123384714127)); }); });</Command>
</JSEvent>
        trigger(police_2, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_2, new LatLng(36.16389646522996, -86.78259640932083)); }); });</Command>
</JSEvent>
        trigger(police_2, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_2, new LatLng(36.164375024681725, -86.78110241889953)); }); });</Command>
</JSEvent>
        trigger(police_2, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_2, new LatLng(36.16365826712878, -86.78243279457092)); }); });</Command>
</JSEvent>
        trigger(police_2, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_2, new LatLng(36.16419962540282, -86.78097367286682)); }); });</Command>
</JSEvent>
        trigger(police_2, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_2, new LatLng(36.1635001898075, -86.78236037492752)); }); });</Command>
</JSEvent>
        trigger(police_2, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_2, new LatLng(36.16399607513039, -86.78230673074722)); }); });</Command>
</JSEvent>
        //bl
        trigger(police_3, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_3, new LatLng(36.16452469841214, -86.78325891494751)); }); });</Command>
</JSEvent>
        trigger(police_3, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_3, new LatLng(36.163842589203114, -86.78448736667633)); }); });</Command>
</JSEvent>
        trigger(police_3, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_3, new LatLng(36.164236697470095, -86.78308725357056)); }); });</Command>
</JSEvent>
        trigger(police_3, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_3, new LatLng(36.16358273651459, -86.78439617156982)); }); });</Command>
</JSEvent>
        trigger(police_3, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_3, new LatLng(36.164054801593096, -86.78294777870178)); }); });</Command>
</JSEvent>
        trigger(police_3, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_3, new LatLng(36.163353199256576, -86.78424060344696)); }); });</Command>
</JSEvent>
        trigger(police_3, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_3, new LatLng(36.163859652843435, -86.78299069404602)); }); });</Command>
</JSEvent>
        trigger(police_3, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_3, new LatLng(36.16317320693955, -86.7841386795044)); }); });</Command>
</JSEvent>
        trigger(police_3, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_3, new LatLng(36.163593303884646, -86.78291022777557)); }); }); 
        trigger(police_3, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_3, new LatLng(36.16297398492088, -86.78410917520523)); }); });</Command>
</JSEvent>
        trigger(police_3, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_3, new LatLng(36.16331829222148, -86.7826983332634)); }); });</Command>
</JSEvent>
        trigger(police_3, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_3, new LatLng(36.163491528027265, -86.78351372480392)); }); });</Command>
</JSEvent>
        //tl
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.16458316463957, -86.78329110145569)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.16410677188674, -86.78464829921722)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.164743405187544, -86.7834198474884)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.16425402086494, -86.78476095199585)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.16487766052959, -86.78350567817688)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.16444457795554, -86.78488433361053)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.16501382119878, -86.78378731012344)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.1645937318665, -86.78497821092605)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.16525851137018, -86.7839053273201)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.164851415796036, -86.78524106740951)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.165429577496525, -86.78402066230774)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.16500082877895, -86.78536981344223)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.165498869998416, -86.78416281938553)); }); });</Command>
</JSEvent>
        trigger(police_4, 'push_event'</Time>
    <Command><JSEvent>
    <Time>500, function() {trigger(map, 'move_item', police_4, new LatLng(36.16479078435941, -86.78435325622558)); }); });</Command>
</JSEvent>
    });</Command>
</JSEvent>

<!--hazmat_5 & _6 move around-->
<JSEvent>
    <Time>6000</Time>
    <Command>trigger(map, 'move_item', hazmat_5, new LatLng(36.16490148000173,  -86.78424596786499)); });</Command>
</JSEvent>
<JSEvent>
    <Time>7000</Time>
    <Command>trigger(map, 'move_item', hazmat_6, new LatLng(36.164834352379856,  -86.78418159484863)); });</Command>
</JSEvent>
<JSEvent>
    <Time>51000</Time>
    <Command>trigger(map, 'move_item', hazmat_5, new LatLng(36.164940457304205,  -86.78414672613144)); });</Command>
</JSEvent>
<JSEvent>
    <Time>57000</Time>
    <Command>trigger(map, 'move_item', hazmat_6, new LatLng(36.164884156749984,  -86.78409039974212)); });</Command>
</JSEvent>
<JSEvent>
    <Time>126000</Time>
    <Command>trigger(map, 'move_item', hazmat_5, new LatLng(36.16498593079923,  -86.78400993347168)); });</Command>
</JSEvent>
<JSEvent>
    <Time>132000</Time>
    <Command>trigger(map, 'move_item', hazmat_6, new LatLng(36.164944788114376,  -86.78392946720123)); });</Command>
</JSEvent>
<JSEvent>
    <Time>201000</Time>
    <Command>trigger(map, 'move_item', hazmat_5, new LatLng(36.16502490805969,  -86.78390800952911)); });</Command>
</JSEvent>
<JSEvent>
    <Time>207000</Time>
    <Command>trigger(map, 'move_item', hazmat_6, new LatLng(36.16500541943189,  -86.78380608558655)); });</Command>
</JSEvent>
<JSEvent>
    <Time>276000</Time>
    <Command>trigger(map, 'move_item', hazmat_5, new LatLng(36.16507254690726,  -86.78380876779556)); });</Command>
</JSEvent>
<JSEvent>
    <Time>282000</Time>
    <Command>trigger(map, 'move_item', hazmat_6, new LatLng(36.165131012726086,  -86.78369075059891)); });</Command>
</JSEvent>
<JSEvent>
    <Time>351000</Time>
    <Command>trigger(map, 'move_item', hazmat_5, new LatLng(36.16507471230873,  -86.78366661071777)); });</Command>
</JSEvent>
<JSEvent>
    <Time>357000</Time>
    <Command>trigger(map, 'move_item', hazmat_6, new LatLng(36.16518081690772,  -86.78355932235718)); });</Command>
</JSEvent>
<JSEvent>
    <Time>426000</Time>
    <Command>trigger(map, 'move_item', hazmat_5, new LatLng(36.16512235112605,  -86.78351640701294)); });</Command>
</JSEvent>
<JSEvent>
    <Time>432000</Time>
    <Command>trigger(map, 'move_item', hazmat_6, new LatLng(36.16523711724884,  -86.78345203399658)); });</Command>
</JSEvent>
<JSEvent>
    <Time>501000</Time>
    <Command>trigger(map, 'move_item', hazmat_5, new LatLng(36.16518081690772,  -86.7834010720253)); });</Command>
</JSEvent>
<JSEvent>
    <Time>507000</Time>
    <Command>trigger(map, 'move_item', hazmat_6, new LatLng(36.165293417549556,  -86.78330451250076)); });</Command>
</JSEvent>
<JSEvent>
    <Time>576000</Time>
    <Command>trigger(map, 'move_item', hazmat_5, new LatLng(36.16523711724884,  -86.78326427936554)); });</Command>
</JSEvent>

<!--hazmat_3 & _4 move around-->
<JSEvent>
    <Time>30000</Time>
    <Command>trigger(map, 'move_item', hazmat_3, new LatLng(36.16534408778476, -86.78323209285736)); });</Command>
</JSEvent>
<JSEvent>
    <Time>30000</Time>
    <Command>trigger(map, 'move_item', hazmat_4, new LatLng(36.16530727607808, -86.78321868181228)); });</Command>
</JSEvent>
<JSEvent>
    <Time>156000</Time>
    <Command>trigger(map, 'move_item', hazmat_3, new LatLng(36.165293417549556,  -86.7831140756607)); });</Command>
</JSEvent>
<JSEvent>
    <Time>159600</Time>
    <Command>trigger(map, 'move_item', hazmat_4, new LatLng(36.165172155313186,  -86.78311139345169)); });</Command>
</JSEvent>
<JSEvent>
    <Time>201000</Time>
    <Command>trigger(map, 'move_item', hazmat_3, new LatLng(36.16521979407126,  -86.78304702043533)); });</Command>
</JSEvent>
<JSEvent>
    <Time>204600</Time>
    <Command>trigger(map, 'move_item', hazmat_4, new LatLng(36.16506821610414,  -86.78294241428375)); });</Command>
</JSEvent>
<JSEvent>
    <Time>246000</Time>
    <Command>trigger(map, 'move_item', hazmat_3, new LatLng(36.165152666722,  -86.78300142288208)); });</Command>
</JSEvent>
<JSEvent>
    <Time>249600</Time>
    <Command>trigger(map, 'move_item', hazmat_4, new LatLng(36.16507471230873,  -86.7830416560173)); });</Command>
</JSEvent>
<JSEvent>
    <Time>291000</Time>
    <Command>trigger(map, 'move_item', hazmat_3, new LatLng(36.165003254028484,  -86.78299069404602)); });</Command>
</JSEvent>
<JSEvent>
    <Time>294600</Time>
    <Command>trigger(map, 'move_item', hazmat_4, new LatLng(36.16495128432922,  -86.78291022777557)); });</Command>
</JSEvent>
<JSEvent>
    <Time>582000</Time>
    <Command>trigger(map, 'move_item', hazmat_3, new LatLng(36.16494669366483, -86.78284853696823)); });</Command>
</JSEvent>
<JSEvent>
    <Time>651000</Time>
    <Command>trigger(map, 'move_item', hazmat_4, new LatLng(36.16490771636549, -86.78291827440262)); });</Command>
</JSEvent>

<!--ems_1-->
<JSEvent>
    <Time>18000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16503114441775, -86.7833286523819)); });</Command>
</JSEvent>
<JSEvent>
    <Time>33000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16481027303645, -86.78366124629974)); });</Command>
</JSEvent>
<JSEvent>
    <Time>48000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16491854339916, -86.78325086832046)); });</Command>
</JSEvent>
<JSEvent>
    <Time>63000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.164704167935895, -86.78357809782028)); });</Command>
</JSEvent>
<JSEvent>
    <Time>78000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16478645353657, -86.78317040205002)); });</Command>
</JSEvent>
<JSEvent>
    <Time>93000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.164530934809996, -86.78357005119324)); });</Command>
</JSEvent>
<JSEvent>
    <Time>108000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16466302510316, -86.78308725357055)); });</Command>
</JSEvent>
<JSEvent>
    <Time>123000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16443782184663, -86.78347885608673)); });</Command>
</JSEvent>
<JSEvent>
    <Time>138000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.164587235617894, -86.7830416560173)); });</Command>
</JSEvent>
<JSEvent>
    <Time>153000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16432738539786, -86.78335547447204)); });</Command>
</JSEvent>
<JSEvent>
    <Time>168000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16444648352228, -86.7829504609108)); });</Command>
</JSEvent>
<JSEvent>
    <Time>183000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16414982058538, -86.78324550390243)); });</Command>
</JSEvent>
<JSEvent>
    <Time>198000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.164277580673975, -86.78283244371414)); });</Command>
</JSEvent>
<JSEvent>
    <Time>213000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16401989485804, -86.78319990634918)); });</Command>
</JSEvent>
<JSEvent>
    <Time>228000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16416497857288, -86.78275734186172)); });</Command>
</JSEvent>
<JSEvent>
    <Time>273000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16410218117704, -86.78273320198059)); });</Command>
</JSEvent>
<JSEvent>
    <Time>279000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16380335150054, -86.78355664014816)); });</Command>
</JSEvent>
<JSEvent>
    <Time>312000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.164015563996756, -86.78293973207474)); });</Command>
</JSEvent>
<JSEvent>
    <Time>327000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.1638336676066, -86.78302824497223)); });</Command>
</JSEvent>
<JSEvent>
    <Time>342000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.163775200820154, -86.7833662033081)); });</Command>
</JSEvent>
<JSEvent>
    <Time>357000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16371889942899, -86.78350567817688)); });</Command>
</JSEvent>
<JSEvent>
    <Time>372000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.163595469314586, -86.7835083603859)); });</Command>
</JSEvent>
<JSEvent>
    <Time>417000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.164032887440456, -86.78245157003402)); });</Command>
</JSEvent>
<JSEvent>
    <Time>450000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16417147485235, -86.78229331970215)); });</Command>
</JSEvent>
<JSEvent>
    <Time>457500</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16412600088482, -86.78255617618561)); });</Command>
</JSEvent>
<JSEvent>
    <Time>465000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.1642645881321, -86.78237110376358)); });</Command>
</JSEvent>
<JSEvent>
    <Time>472500</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16420395624157, -86.78258836269378)); });</Command>
</JSEvent>
<JSEvent>
    <Time>480000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.164316558286636, -86.78238987922668)); });</Command>
</JSEvent>
<JSEvent>
    <Time>487500</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.1642710844033, -86.78264200687408)); });</Command>
</JSEvent>
<JSEvent>
    <Time>495000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16437719009009, -86.7824274301529)); });</Command>
</JSEvent>
<JSEvent>
    <Time>502500</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.164318723709, -86.78267687559128)); });</Command>
</JSEvent>
<JSEvent>
    <Time>510000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16443782184663, -86.7824649810791)); });</Command>
</JSEvent>
<JSEvent>
    <Time>517500</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16440317513434, -86.7827358841896)); });</Command>
</JSEvent>
<JSEvent>
    <Time>525000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16464137097198, -86.78259640932083)); });</Command>
</JSEvent>
<JSEvent>
    <Time>532500</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16465003262517, -86.78289949893951)); });</Command>
</JSEvent>
<JSEvent>
    <Time>540000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.164788618945955, -86.78270906209945)); });</Command>
</JSEvent>
<JSEvent>
    <Time>547500</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16476263402947, -86.78297460079193)); });</Command>
</JSEvent>
<JSEvent>
    <Time>555000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.164883896899354, -86.78280025720596)); });</Command>
</JSEvent>
<JSEvent>
    <Time>562500</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.164873069865024, -86.78303360939026)); });</Command>
</JSEvent>
<JSEvent>
    <Time>570000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16500082877481, -86.78285390138626)); });</Command>
</JSEvent>
<JSEvent>
    <Time>577500</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16496185150239, -86.7830953001976)); });</Command>
</JSEvent>
<JSEvent>
    <Time>585000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16507878326153, -86.78290218114853)); });</Command>
</JSEvent>
<JSEvent>
    <Time>592500</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.165028979015084, -86.78314357995987)); });</Command>
</JSEvent>
<JSEvent>
    <Time>600000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16518705325337, -86.7829692363739)); });</Command>
</JSEvent>
<JSEvent>
    <Time>607500</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.165128587476346, -86.7832213640213)); });</Command>
</JSEvent>
<JSEvent>
    <Time>615000</Time>
    <Command>trigger(map, 'move_item', ems_1, new LatLng(36.16527583453509, -86.78304970264435)); });</Command>
</JSEvent>

<!--ems_2-->
<JSEvent>
    <Time>66000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.165173021472754,  -86.78323745727539)); });</Command>
</JSEvent>
<JSEvent>
    <Time>87000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16525097578823,  -86.78301483392715)); });</Command>
</JSEvent>
<JSEvent>
    <Time>108000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.165116721085575,  -86.78321063518524)); });</Command>
</JSEvent>
<JSEvent>
    <Time>129000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16518384846566,  -86.78297191858291)); });</Command>
</JSEvent>
<JSEvent>
    <Time>150000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16505392445218,  -86.78318917751312)); });</Command>
</JSEvent>
<JSEvent>
    <Time>171000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16512321728617,  -86.78293168544769)); });</Command>
</JSEvent>
<JSEvent>
    <Time>192000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16499762397949,  -86.78313821554184)); });</Command>
</JSEvent>
<JSEvent>
    <Time>213000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.165073413067944,  -86.78289145231247)); });</Command>
</JSEvent>
<JSEvent>
    <Time>234000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16491966941206,  -86.78307920694351)); });</Command>
</JSEvent>
<JSEvent>
    <Time>255000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16498463155697,  -86.78281635046005)); });</Command>
</JSEvent>
<JSEvent>
    <Time>276000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.164861203435606,  -86.78304702043533)); });</Command>
</JSEvent>
<JSEvent>
    <Time>297000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.164947819681444,  -86.782805621624)); });</Command>
</JSEvent>
<JSEvent>
    <Time>318000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.164830887726936,  -86.78300946950912)); });</Command>
</JSEvent>
<JSEvent>
    <Time>339000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.164904511570484,  -86.78277611732483)); });</Command>
</JSEvent>
<JSEvent>
    <Time>360000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16479624118838,  -86.78296387195587)); });</Command>
</JSEvent>
<JSEvent>
    <Time>381000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16485254180575,  -86.78274393081665)); });</Command>
</JSEvent>
<JSEvent>
    <Time>402000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.1647464367624,  -86.78291827440262)); });</Command>
</JSEvent>
<JSEvent>
    <Time>423000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16480057200654,  -86.78270637989044)); });</Command>
</JSEvent>
<JSEvent>
    <Time>444000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.164687970656736,  -86.78288608789444)); });</Command>
</JSEvent>
<JSEvent>
    <Time>465000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16476159463453,  -86.78267687559128)); });</Command>
</JSEvent>
<JSEvent>
    <Time>486000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16462950450747,  -86.78284853696823)); });</Command>
</JSEvent>
<JSEvent>
    <Time>507000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16470745936347,  -86.78263664245605)); });</Command>
</JSEvent>
<JSEvent>
    <Time>528000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.164623008265956,  -86.78284049034118)); });</Command>
</JSEvent>
<JSEvent>
    <Time>549000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16468580524458,  -86.78263127803802)); });</Command>
</JSEvent>
<JSEvent>
    <Time>570000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16456670748376,  -86.7828243970871)); });</Command>
</JSEvent>
<JSEvent>
    <Time>591000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.164648993228724,  -86.78261250257492)); });</Command>
</JSEvent>
<JSEvent>
    <Time>612000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.164425955351284,  -86.78276002407074)); });</Command>
</JSEvent>
<JSEvent>
    <Time>633000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16449091790537,  -86.7825186252594)); });</Command>
</JSEvent>
<JSEvent>
    <Time>654000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16437398526926,  -86.7826983332634)); });</Command>
</JSEvent>
<JSEvent>
    <Time>675000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16441729367334,  -86.78247034549713)); });</Command>
</JSEvent>
<JSEvent>
    <Time>696000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16429386465862,  -86.78265810012817)); });</Command>
</JSEvent>
<JSEvent>
    <Time>717000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16436748900657,  -86.78243815898895)); });</Command>
</JSEvent>
<JSEvent>
    <Time>738000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.164237563640015,  -86.78262323141098)); });</Command>
</JSEvent>
<JSEvent>
    <Time>759000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16432851141923,  -86.78240865468979)); });</Command>
</JSEvent>
<JSEvent>
    <Time>780000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.164213743966094,  -86.78259909152984)); });</Command>
</JSEvent>
<JSEvent>
    <Time>801000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16428736838932,  -86.78237915039062)); });</Command>
</JSEvent>
<JSEvent>
    <Time>822000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16420291683922,  -86.78258568048477)); });</Command>
</JSEvent>
<JSEvent>
    <Time>843000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16426787957814,  -86.78235501050949)); });</Command>
</JSEvent>
<JSEvent>
    <Time>864000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16417260087596,  -86.7825910449028)); });</Command>
</JSEvent>
<JSEvent>
    <Time>885000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16425272161054,  -86.78233623504638)); });</Command>
</JSEvent>
<JSEvent>
    <Time>906000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16414445032816,  -86.78258299827575)); });</Command>
</JSEvent>
<JSEvent>
    <Time>927000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16422024024153,  -86.78232282400131)); });</Command>
</JSEvent>
<JSEvent>
    <Time>948000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16411413434228,  -86.78256154060364)); });</Command>
</JSEvent>
<JSEvent>
    <Time>969000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16418775885906,  -86.78229600191116)); });</Command>
</JSEvent>
<JSEvent>
    <Time>990000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.164064329482926,  -86.78251594305038)); });</Command>
</JSEvent>
<JSEvent>
    <Time>1011000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16413145776422,  -86.78228259086609)); });</Command>
</JSEvent>
<JSEvent>
    <Time>1032000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16405350233539,  -86.78250521421432)); });</Command>
</JSEvent>
<JSEvent>
    <Time>1053000</Time>
    <Command>trigger(map, 'move_item', ems_2, new LatLng(36.16456021123705,  -86.78329646587372)); });</Command>
</JSEvent>

<!--ems_3-->
<JSEvent>
    <Time>33000</Time>
    <Command>trigger(map, 'move_item', ems_3, new LatLng(36.16500732498088,  -86.78372293710708)); });</Command>
</JSEvent>
<JSEvent>
    <Time>57000</Time>
    <Command>trigger(map, 'move_item', ems_3, new LatLng(36.16494019744963,  -86.7835459113121)); });</Command>
</JSEvent>
<JSEvent>
    <Time>64101</Time>
    <Command>trigger(map, 'move_item', ems_3, new LatLng (36.16499242701067,  -86.78335279226303)); });</Command>
</JSEvent>
<JSEvent>
    <Time>109107</Time>
    <Command>trigger(map, 'move_item', ems_3, new LatLng (36.16476289388051,  -86.78346008062362)); });</Command>
</JSEvent>
<JSEvent>
    <Time>144777</Time>
    <Command>trigger(map, 'move_item', ems_3, new LatLng(36.1646648873718,  -86.78337961435318)); });</Command>
</JSEvent>
<JSEvent>
    <Time>149532</Time>
    <Command>trigger(map, 'move_item', ems_3, new LatLng(36.16462647292811,  -86.78330719470978)); });</Command>
</JSEvent>
<JSEvent>
    <Time>182607</Time>
    <Command>trigger(map, 'move_item', ems_3, new LatLng (36.164539856327146,  -86.783167719841)); });</Command>
</JSEvent>
<JSEvent>
    <Time>218763</Time>
    <Command>trigger(map, 'move_item', ems_3, new LatLng(36.164461338307554,  -86.7832562327385)); });</Command>
</JSEvent>
<JSEvent>
    <Time>253200</Time>
    <Command>trigger(map, 'move_item', ems_3, new LatLng (36.16429083306628,  -86.78318113088608)); });</Command>
</JSEvent>
<JSEvent>
    <Time>290187</Time>
    <Command>trigger(map, 'move_item', ems_3, new LatLng(36.16417364027459,  -86.78309261798858)); });</Command>
</JSEvent>
<JSEvent>
    <Time>325695</Time>
    <Command>trigger(map, 'move_item', ems_3, new LatLng (36.164267013408576,  -86.78286999464035)); });</Command>
</JSEvent>

<!--ems_4-->
<JSEvent>
    <Time>36000</Time>
    <Command>trigger(map, 'move_item', ems_4, new LatLng(36.1650463022307,  -86.78369343280792)); });</Command>
</JSEvent>
<JSEvent>
    <Time>60000</Time>
    <Command>trigger(map, 'move_item', ems_4, new LatLng(36.16494019744963,  -86.7835459113121)); });</Command>
</JSEvent>
<JSEvent>
    <Time>66813</Time>
    <Command>trigger(map, 'move_item', ems_4, new LatLng (36.164940457304226,  -86.78347617387771)); });</Command>
</JSEvent>
<JSEvent>
    <Time>99429</Time>
    <Command>trigger(map, 'move_item', ems_4, new LatLng (36.16474557059812,  -86.78356200456619)); });</Command>
</JSEvent>
<JSEvent>
    <Time>137415</Time>
    <Command>trigger(map, 'move_item', ems_4, new LatLng(36.16465406030728,  -86.78335011005401)); });</Command>
</JSEvent>
<JSEvent>
    <Time>146070</Time>
    <Command>trigger(map, 'move_item', ems_4, new LatLng (36.16464596165013,  -86.78321063518524)); });</Command>
</JSEvent>
<JSEvent>
    <Time>181308</Time>
    <Command>trigger(map, 'move_item', ems_4, new LatLng (36.1644640667228,  -86.78324550390243)); });</Command>
</JSEvent>
<JSEvent>
    <Time>188253</Time>
    <Command>trigger(map, 'move_item', ems_4, new LatLng (36.16421287779595,  -86.78319722414017)); });</Command>
</JSEvent>
<JSEvent>
    <Time>197844</Time>
    <Command>trigger(map, 'move_item', ems_4, new LatLng (36.16404180901432,  -86.78310066461563)); });</Command>
</JSEvent>

<!--ems_5-->
<JSEvent>
    <Time>39000</Time>
    <Command>trigger(map, 'move_item', ems_5, new LatLng(36.16504413682844,  -86.78365588188171)); });</Command>
</JSEvent>
<JSEvent>
    <Time>63000</Time>
    <Command>trigger(map, 'move_item', ems_5, new LatLng (36.1648754951227,  -86.78355664014816)); });</Command>
</JSEvent>
<JSEvent>
    <Time>100338</Time>
    <Command>trigger(map, 'move_item', ems_5, new LatLng (36.164674112017835,  -86.78346276283264)); });</Command>
</JSEvent>
<JSEvent>
    <Time>138669</Time>
    <Command>trigger(map, 'move_item', ems_5, new LatLng (36.1644575704676,  -86.78339302539825)); });</Command>
</JSEvent>
<JSEvent>
    <Time>177201</Time>
    <Command>trigger(map, 'move_item', ems_5, new LatLng (36.16438611162475,  -86.78330987691879)); });</Command>
</JSEvent>
<JSEvent>
    <Time>211311</Time>
    <Command>trigger(map, 'move_item', ems_5, new LatLng (36.164195554392016,  -86.78305774927139)); });</Command>
</JSEvent>

<!--ems_6-->
<JSEvent>
    <Time>42000</Time>
    <Command>trigger(map, 'move_item', ems_6, new LatLng(36.16504413682844,  -86.78365588188171)); });</Command>
</JSEvent>
<JSEvent>
    <Time>66000</Time>
    <Command>trigger(map, 'move_item', ems_6, new LatLng (36.164871164308664,  -86.78363710641861)); });</Command>
</JSEvent>
<JSEvent>
    <Time>102525</Time>
    <Command>trigger(map, 'move_item', ems_6, new LatLng (36.164604818786834,  -86.78337961435318)); });</Command>
</JSEvent>
<JSEvent>
    <Time>146418</Time>
    <Command>trigger(map, 'move_item', ems_6, new LatLng (36.16445323963048,  -86.7835083603859)); });</Command>
</JSEvent>
<JSEvent>
    <Time>183876</Time>
    <Command>trigger(map, 'move_item', ems_6, new LatLng (36.16436662283812,  -86.7832562327385)); });</Command>
</JSEvent>
<JSEvent>
    <Time>223872</Time>
    <Command>trigger(map, 'move_item', ems_6, new LatLng(36.164457007458786,  -86.78322404623031)); });</Command>
</JSEvent>
<JSEvent>
    <Time>227469</Time>
    <Command>trigger(map, 'move_item', ems_6, new LatLng(36.16454362415128,  -86.7830228805542)); });</Command>
</JSEvent>
<JSEvent>
    <Time>235683</Time>
    <Command>trigger(map, 'move_item', ems_6, new LatLng (36.16435796115361,  -86.78290218114853)); });</Command>
</JSEvent>

<!--hazmat_1 & _2-->
<JSEvent>
    <Time>20572</Time>
    <Command>trigger(map, 'move_item', hazmat_1, new LatLng(36.16426138330668, -86.7828431725502)); });</Command>
</JSEvent>
<JSEvent>
    <Time>45572</Time>
    <Command>trigger(map, 'move_item', hazmat_2, new LatLng(36.164341503950496, -86.78346812725067)); });</Command>
</JSEvent>
<JSEvent>
    <Time>88030</Time>
    <Command>trigger(map, 'move_item', hazmat_1, new LatLng(36.164672812770384, -86.78213238716125)); });</Command>
</JSEvent>
<JSEvent>
    <Time>122275</Time>
    <Command>trigger(map, 'move_item', hazmat_2, new LatLng(36.16486769965735, -86.7832401394844)); });</Command>
</JSEvent>
<JSEvent>
    <Time>139966</Time>
    <Command>trigger(map, 'move_item', hazmat_1, new LatLng(36.16513620968572, -86.78339302539825)); });</Command>
</JSEvent>
<JSEvent>
    <Time>131829</Time>
    <Command>trigger(map, 'move_item', hazmat_2, new LatLng(36.163802312092876, -86.78354322910309)); });</Command>
</JSEvent>
<JSEvent>
    <Time>201889</Time>
    <Command>trigger(map, 'move_item', hazmat_1, new LatLng(36.16398637398733, -86.78294509649277)); });</Command>
</JSEvent>
